//
//  AppDelegate.h
//  testKCPCardSample
//
//  Created by kcpmac on 12. 9. 20..
//  Copyright (c) 2012년 kcpmac. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    ViewController *viewController;
}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end