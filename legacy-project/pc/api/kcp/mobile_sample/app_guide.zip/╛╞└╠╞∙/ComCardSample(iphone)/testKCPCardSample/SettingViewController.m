//
//  SettingViewController.m
//  testKCPCardSample
//
//  Created by kcpmac on 12. 9. 21..
//  Copyright (c) 2012년 kcpmac. All rights reserved.
//

#import "SettingViewController.h"

@interface SettingViewController ()

@end

@implementation SettingViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(IBAction)check:(id)sender
{
    UIButton *tempBtn=(UIButton *)sender;
    NSInteger nTag=tempBtn.tag;
    
    if (nTag==100)
    {
        NSLog(@"100");
    }
    else if(nTag==200)
    {
        NSLog(@"200");
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
