//
//  main.m
//  testKCPCardSample
//
//  Created by kcpmac on 12. 9. 20..
//  Copyright (c) 2012년 kcpmac. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
